<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'wordpress' );

/** MySQL database password */
define( 'DB_PASSWORD', 'wordpress' );

/** MySQL hostname */
define( 'DB_HOST', 'database' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '?LIBcpT3ghXd:bNKf}60=NN6T9VtUHJ^g}^Ca7xqgQwTd<lXW$OP/Q(@B[JIZnF>' );
define( 'SECURE_AUTH_KEY',  '@Tl=_b%M-1%>0mHPlN0aY!wG4B6tzy!T>`bw6U-HP@^<)<4U0B[(|4M38Ich`aEE' );
define( 'LOGGED_IN_KEY',    '~[vB){LIO4}/oV`y5%?G?6U3$Kwe<Zo*!V,n+XQS.Ndj$Tb2B-A^OL#G8`C!ZH&Q' );
define( 'NONCE_KEY',        '4#`cZZGZUg<n@*3iA~36p Y17}P$PV@&e_}js.oF;0NSHKHUA_ScD.(&^8qKIE>F' );
define( 'AUTH_SALT',        'm-h.d)Y}ILEnewGxpt2kZ02]v[Z((q7|Ov&gwS~h^nH&}5l_D3bGYGGE97`VbOfz' );
define( 'SECURE_AUTH_SALT', ':%9ND.iQ1d/(mV9:?tYm~3<9]_ZBCRt;3P20K{7SD]?rRJ#lIkl;$[^+Hu9t$(]>' );
define( 'LOGGED_IN_SALT',   ' HXxb<yte{^_nVQX55X1L=Y}2i<-ApOANSv.1OheLAr I2LLgEEla|fuxQ7yIfUO' );
define( 'NONCE_SALT',       'e@#si`KIR0&Mb#q>yfSZd8j#pSYVp0FYatWu[I@^)$8w ,`TDEQd+UOxDnO,Gt=6' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
