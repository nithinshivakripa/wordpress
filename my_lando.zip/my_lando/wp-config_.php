<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'wordpress' );

/** MySQL database password */
define( 'DB_PASSWORD', 'wordpress' );

/** MySQL hostname */
define( 'DB_HOST', 'database' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'auPCZa7q/YEMR1mlDS6Yc+zbdyldNqF74IafzTpb2bveWDamO0Mtk7al10pRuSyyhoT4NxxG7dE2hFdCOzweTA==');
define('SECURE_AUTH_KEY',  '5W/ZNTZWeB7x5fcSe6JTmkIrg8Mv3nNwkBjaHbFgxB5ZSSwrFyU96P40cSWhdloKkeoXBUFNqg/DVslOmVOstg==');
define('LOGGED_IN_KEY',    'S5joxbnaGE2pWIlH2+pIF6F/vThv1QNCF2yIn6BlVN2tq9amhMT/hHTV4/rnWs4j0YZRLAz8XValulnMjXUKkw==');
define('NONCE_KEY',        'Cxz1gyAlyZsAoANsBGlsgOc4dvSybkF32sDYMpfqHyhE1YFg/q2jt3EaeMVygQivunTJ4K2qWkdea5e7U8PYWw==');
define('AUTH_SALT',        '9sCNJaJvxx5HxElwvhjE2DBurAizxox+oebWVsOgNCCiXx0Xj0lT5aJqyqxsmcgxkyllkNn8GXdBgIzgv/oyWg==');
define('SECURE_AUTH_SALT', 'cp/qD/fPmMckn6WL6PrBW++bPX4QObLr6G7wJLPcLiWtGPQpUWPBwOArT/3cxeuZ/HXFWnhIaGNF3HR9pSSSwA==');
define('LOGGED_IN_SALT',   'ge2iP1YOvDiLKOjuXdCQNjF1fMASRuPh+LGP/JZ47uwY5pei1HwD0uKxn7DEJDE6GVI0pzwNKsGfLZghSujBkw==');
define('NONCE_SALT',       'dNNi6H/f04PLwfx7FoFhNBbgGMQrvQz3l+dg0dnnqPV7Kv1T1zY9laLN0CaKdbDv8DEaxjsMSHe5FkH9tKyfWQ==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
