<?php

function wordpress_files(){
  wp_enqueue_script('main-university-js',get_theme_file_uri('/js/scripts-bundled.js'), NULL,'1.0', microtime(), true);
  wp_enqueue_style('font-awesome','https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');  //style including
  wp_enqueue_style('wordpress_main_styles',get_stylesheet_uri(), NULL, microtime());
  wp_enqueue_script( 'script', get_template_directory_uri() . '/script.js', array ( 'jquery' ), 1.1, true);
}
function wordpress_features(){


  add_theme_support('title-tag');
}
add_action('wp_enqueue_scripts','wordpress_files');
add_action('after_setup_theme','wordpress_features');
function wordpress_adjust_queries($query){
  if (!is_admin() AND is_post_type_archive('event') AND $query->is_main_query()){ //condition checking for display post by created date
      $today = date('Ymd');
      $query->set('meta_key', 'event_date');
      $query->set('orderby', 'meta_value_num');
      $query->set('order', 'ASC');
      $query->set('meta_query', array(
        array(
        'key' =>'event_date',
        'compare' => '>=',
        'value' => $today,
        'type' => 'numeric'
      )
    ));

  }
}
add_action('pre_get_posts', 'wordpress_adjust_queries');
?>
