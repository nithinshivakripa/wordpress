<?php

function wordpress_files(){
  wp_enqueue_script('main-university-js',get_theme_file_uri('/js/scripts-bundled.js'), NULL,'1.0', microtime(), true);
  wp_enqueue_style('font-awesome','https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
  wp_enqueue_style('wordpress_main_styles',get_stylesheet_uri(), NULL, microtime());
  wp_enqueue_script( 'script', get_template_directory_uri() . '/script.js', array ( 'jquery' ), 1.1, true);
}
function wordpress_features(){


  add_theme_support('title-tag');
}
add_action('wp_enqueue_scripts','wordpress_files');
add_action('after_setup_theme','wordpress_features');





 ?>
