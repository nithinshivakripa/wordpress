/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_usermeta` VALUES
(1,1,"nickname","Nithin"),
(2,1,"first_name",""),
(3,1,"last_name",""),
(4,1,"description",""),
(5,1,"rich_editing","true"),
(6,1,"syntax_highlighting","true"),
(7,1,"comment_shortcuts","false"),
(8,1,"admin_color","fresh"),
(9,1,"use_ssl","0"),
(10,1,"show_admin_bar_front","true"),
(11,1,"locale",""),
(12,1,"wp_capabilities","a:1:{s:13:\"administrator\";b:1;}"),
(13,1,"wp_user_level","10"),
(14,1,"dismissed_wp_pointers","plugin_editor_notice"),
(15,1,"show_welcome_panel","1"),
(17,1,"wp_dashboard_quick_press_last_post_id","82"),
(18,1,"community-events-location","a:1:{s:2:\"ip\";s:12:\"192.168.95.0\";}"),
(20,1,"managenav-menuscolumnshidden","a:4:{i:0;s:11:\"link-target\";i:1;s:15:\"title-attribute\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}"),
(21,1,"metaboxhidden_nav-menus","a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}"),
(23,1,"nav_menu_recently_edited","4"),
(24,1,"wp_user-settings","libraryContent=browse&editor=tinymce&mfold=o"),
(25,1,"wp_user-settings-time","1568020763"),
(26,1,"session_tokens","a:1:{s:64:\"196dafafdfcaa4c6b37265794039955b34316a61ffd800b27ed951879c7c6639\";a:4:{s:10:\"expiration\";i:1568873433;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:119:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.9 Safari/537.36\";s:5:\"login\";i:1568700633;}}"),
(27,1,"closedpostboxes_page","a:0:{}"),
(28,1,"metaboxhidden_page","a:5:{i:0;s:10:\"postcustom\";i:1;s:16:\"commentstatusdiv\";i:2;s:11:\"commentsdiv\";i:3;s:7:\"slugdiv\";i:4;s:9:\"authordiv\";}");
