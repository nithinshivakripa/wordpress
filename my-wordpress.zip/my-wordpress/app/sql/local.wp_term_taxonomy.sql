/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_term_taxonomy` VALUES
(1,1,"category","",0,2),
(2,2,"nav_menu","",0,14),
(3,3,"nav_menu","",0,2),
(4,4,"nav_menu","",0,2),
(5,5,"nav_menu","",0,2),
(6,6,"category","",0,1);
