/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_terms` VALUES
(1,"Uncategorized","uncategorized",0),
(2,"services","services",0),
(3,"My Main Header Menu","my-main-header-menu",0),
(4,"My Magical Menu","my-magical-menu",0),
(5,"My Footer Menu","my-footer-menu",0),
(6,"awards","awards",0);
